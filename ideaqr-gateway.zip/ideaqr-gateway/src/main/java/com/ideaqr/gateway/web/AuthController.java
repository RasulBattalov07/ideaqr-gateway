package com.ideaqr.gateway.web;

import com.ideaqr.gateway.domain.User;
import com.ideaqr.gateway.dto.ApiResponse;
import com.ideaqr.gateway.dto.CurrentUserResponse;
import com.ideaqr.gateway.dto.RegistrationRequest;
import com.ideaqr.gateway.service.UserService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Account endpoints: register a new user and report the current session's
 * profile. Login and logout are handled by Spring Security ({@code /login},
 * {@code /logout}).
 */
@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
public class AuthController {

    private final UserService userService;
    private final AuthSupport authSupport;

    /**
     * Register a new account. Returns the username and Russian profession label;
     * the SPA then performs an automatic login.
     */
    @PostMapping("/register")
    public ResponseEntity<ApiResponse> register(@Valid @RequestBody RegistrationRequest request) {
        User user = userService.register(request);
        ApiResponse body = ApiResponse.ok("Регистрация прошла успешно. Выполняется вход…")
                .with("username", user.getUsername())
                .with("admin", user.isAdmin())
                .with("professionLabel", userService.professionLabel(user.getProfession()));
        return ResponseEntity.status(HttpStatus.CREATED).body(body);
    }

    /**
     * Profile of the authenticated user. Unauthenticated requests are stopped by
     * the security entry point with 401, which the SPA uses to show the login
     * screen.
     */
    @GetMapping("/me")
    public ResponseEntity<CurrentUserResponse> me(Authentication authentication) {
        User user = authSupport.requireUser(authentication);
        return ResponseEntity.ok(userService.buildCurrentUser(user));
    }
}
